# Invoice Authentication System

Built for Equity Bank using Python, MySQL, and Ethereum Smart Contracts.